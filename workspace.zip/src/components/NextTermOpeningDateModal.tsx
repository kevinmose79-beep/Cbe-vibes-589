import React, { useState, useEffect, useRef } from 'react';
import { Calendar, CheckCircle2, X, Download, Clock, Info, Loader2 } from 'lucide-react';
import { Examination, SchoolTerm } from '../types';
import { formatKenyaDate } from '../utils/kenyaDateUtils';
import { resolveSuggestedNextTermOpeningDate, validateNextTermOpeningDate } from '../services/nextTermOpeningDateResolver';

export interface NextTermOpeningDateModalProps {
  isOpen: boolean;
  exam?: Examination;
  schoolTerms?: SchoolTerm[];
  initialDate?: string;
  onConfirm: (confirmedDate: string) => void;
  onClose: () => void;
  isProcessing?: boolean;
  downloadContext?: 'single' | 'batch' | 'zip';
  studentName?: string;
  totalCount?: number;
  cohortCount?: number;
  reportType?: 'terminal' | 'assessment';
  reportTitle?: string;
  categoryLabel?: string;
  termName?: string;
  year?: number | string;
  batchProgress?: { current: number; total: number } | null;
}

export const NextTermOpeningDateModal: React.FC<NextTermOpeningDateModalProps> = ({
  isOpen,
  exam,
  schoolTerms = [],
  initialDate = '',
  onConfirm,
  onClose,
  isProcessing = false,
  downloadContext = 'single',
  studentName,
  totalCount,
  cohortCount,
  reportType = 'terminal',
  reportTitle,
  categoryLabel,
  termName,
  year,
  batchProgress,
}) => {
  const suggested = resolveSuggestedNextTermOpeningDate(exam, schoolTerms);
  const effectiveCount = (typeof totalCount === 'number' ? totalCount : cohortCount) || 0;

  const progressPercent = batchProgress && batchProgress.total > 0
    ? Math.min(100, Math.max(0, Math.round((batchProgress.current / batchProgress.total) * 100)))
    : null;

  const effectiveCategoryLabel = categoryLabel || 'TERMINAL REPORT';
  const effectiveReportTitle = reportTitle || 'Terminal Report';
  const effectiveTerm = termName || exam?.term || '';
  const effectiveYear = year || exam?.year || '';

  // Initialize date selection: either passed initialDate, suggested rawDate, or empty
  const [selectedDate, setSelectedDate] = useState<string>('');
  const dateInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      if (initialDate && initialDate.trim()) {
        setSelectedDate(initialDate.trim());
      } else if (suggested?.rawDate) {
        setSelectedDate(suggested.rawDate);
      } else {
        setSelectedDate('');
      }
    }
  }, [isOpen, initialDate, suggested?.rawDate]);

  if (!isOpen) return null;

  const isDateValid = Boolean(selectedDate && validateNextTermOpeningDate(selectedDate));
  const formattedPreview = isDateValid ? formatKenyaDate(selectedDate) : '';

  const handleConfirm = () => {
    if (!isDateValid) return;
    onConfirm(selectedDate.trim());
  };

  const getBadgeText = () => {
    if (downloadContext === 'batch') {
      return effectiveCount > 0
        ? `Batch: ${effectiveCount} Terminal Reports`
        : 'Batch: Terminal Reports';
    }
    if (downloadContext === 'zip') {
      return 'ZIP Archive';
    }
    return 'Terminal Report';
  };

  return (
    <div
      id="next-term-date-modal-backdrop"
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-labelledby="next-term-date-modal-title"
    >
      <div
        id="next-term-date-modal-card"
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl max-w-md w-full overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/40">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700/60 flex items-center justify-center text-emerald-800 dark:text-emerald-300 shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2
                id="next-term-date-modal-title"
                className="text-base font-extrabold text-slate-900 dark:text-slate-100 tracking-tight"
              >
                Next School Opening Date
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Official Report Card Verification Gate
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isProcessing}
            aria-label="Close dialog"
            className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition disabled:opacity-50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Terminal Report Context Banner */}
          <div className="bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 rounded-xl p-3 flex items-center justify-between gap-2">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300">
                {effectiveCategoryLabel}
              </span>
              <div className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                {effectiveReportTitle}
              </div>
              {(effectiveTerm || effectiveYear) && (
                <div className="text-[11px] text-slate-600 dark:text-slate-400">
                  {[effectiveTerm, effectiveYear].filter(Boolean).join(' ')}
                </div>
              )}
            </div>
            <span className="px-2.5 py-1 text-[10px] font-extrabold rounded-md bg-emerald-100 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-700/60 shrink-0">
              {getBadgeText()}
            </span>
          </div>

          {/* Explanation Text */}
          <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
            <p>
              Select the next opening date for this terminal report.
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              This date will appear on the terminal report PDF.
            </p>
            {downloadContext === 'batch' && effectiveCount > 0 && (
              <p className="text-emerald-700 dark:text-emerald-400 font-semibold pt-0.5">
                This confirmed date will be applied uniformly to all {effectiveCount} report cards in this batch download.
              </p>
            )}
            {downloadContext === 'single' && studentName && (
              <p className="text-slate-700 dark:text-slate-300 pt-0.5">
                Report for learner: <strong className="text-slate-900 dark:text-slate-100">{studentName}</strong>
              </p>
            )}
          </div>

          {/* Suggested Date Pill / Source */}
          {suggested ? (
            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-3 space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#176B45] dark:text-emerald-400" />
                  <span>Configured Term Schedule</span>
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                  {suggested.subsequentTermName}
                </span>
              </div>
              <div className="flex items-center justify-between pt-0.5">
                <span className="font-extrabold text-slate-900 dark:text-slate-100">
                  {suggested.formattedDate}
                </span>
                {selectedDate !== suggested.rawDate && (
                  <button
                    type="button"
                    onClick={() => setSelectedDate(suggested.rawDate)}
                    className="text-[10px] font-bold text-[#176B45] dark:text-emerald-400 hover:underline cursor-pointer"
                  >
                    Reset to Configured
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-xl p-3 flex items-start space-x-2 text-xs text-amber-900 dark:text-amber-200">
              <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">No Pre-Configured Schedule Found</div>
                <div className="text-[11px] text-amber-800 dark:text-amber-300 mt-0.5">
                  The subsequent term opening date is not set in Academic Sessions. Please specify the date below.
                </div>
              </div>
            </div>
          )}

          {/* Date Selector Input */}
          <div className="space-y-1.5">
            <label
              htmlFor="next-term-date-input"
              className="block text-xs font-extrabold text-slate-900 dark:text-slate-100"
            >
              Next Opening Date <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                ref={dateInputRef}
                id="next-term-date-input"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                onClick={() => {
                  try {
                    dateInputRef.current?.showPicker?.();
                  } catch {}
                }}
                disabled={isProcessing}
                required
                className="w-full h-10 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#176B45]/20 focus:border-[#176B45] disabled:opacity-50 transition cursor-pointer"
              />
            </div>
            {selectedDate && !isDateValid && (
              <p className="text-[11px] text-rose-600 dark:text-rose-400 font-semibold pt-0.5">
                Please select or enter a valid date.
              </p>
            )}
            {formattedPreview && (
              <div className="flex items-center space-x-1.5 text-[11px] text-emerald-800 dark:text-emerald-300 font-semibold pt-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Will appear on official PDF as: <strong>{formattedPreview}</strong></span>
              </div>
            )}
          </div>

          {/* Active Generation Progress Indicator with Percentages */}
          {isProcessing && downloadContext === 'batch' && (
            <div
              id="batch-progress-card"
              className="bg-emerald-50/90 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 rounded-xl p-3.5 space-y-2.5 animate-in fade-in duration-150"
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2 text-emerald-900 dark:text-emerald-200 font-bold">
                  <Loader2 className="w-4 h-4 animate-spin text-[#176B45] dark:text-emerald-400 shrink-0" />
                  <span>Generating Batch PDF Reports...</span>
                </div>
                <div className="font-mono font-extrabold text-[#176B45] dark:text-emerald-300 text-sm">
                  {progressPercent !== null ? `${progressPercent}%` : '0%'}
                </div>
              </div>

              {/* Visual Progress Track */}
              <div className="w-full bg-slate-200 dark:bg-slate-700/80 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-[#176B45] dark:bg-emerald-500 h-full transition-all duration-300 ease-out rounded-full"
                  style={{ width: `${progressPercent !== null ? Math.max(progressPercent, 5) : 5}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span>
                  {batchProgress && batchProgress.total > 0
                    ? `Processed ${batchProgress.current} of ${batchProgress.total} learner report cards`
                    : `Compiling ${effectiveCount > 0 ? effectiveCount : ''} report cards...`}
                </span>
                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold">
                  Please keep this open
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Action Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/40 flex items-center justify-end space-x-3">
          <button
            type="button"
            id="cancel-next-term-date-btn"
            onClick={onClose}
            disabled={isProcessing}
            className="px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700/60 rounded-xl transition cursor-pointer disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            id="confirm-download-next-term-date-btn"
            onClick={handleConfirm}
            disabled={!isDateValid || isProcessing}
            className="bg-[#176B45] hover:bg-[#0F5132] disabled:opacity-50 disabled:cursor-not-allowed text-white px-5 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center space-x-2 cursor-pointer"
          >
            {isProcessing ? (
              <Loader2 className="w-4 h-4 animate-spin shrink-0" />
            ) : (
              <Download className="w-4 h-4 shrink-0" />
            )}
            <span>
              {isProcessing
                ? downloadContext === 'batch'
                  ? progressPercent !== null
                    ? `Generating Batch PDF (${progressPercent}%)...`
                    : 'Generating Batch PDF...'
                  : 'Generating PDF...'
                : downloadContext === 'batch'
                ? `Confirm & Generate Batch PDF`
                : 'Confirm & Download PDF'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
