import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Award,
  Filter,
  Users,
  AlertTriangle,
  ShieldCheck,
  RefreshCw,
  Loader2,
  FileText,
  CheckCircle2,
  HelpCircle,
  Info,
  Clock,
  Eye,
  Download,
  FileDown,
  Printer,
} from 'lucide-react';
import {
  School,
  Student,
  Subject,
  Examination,
  Mark,
  Grade,
  ClassStream,
  Teacher,
  User,
  sortClasses,
  getStudentFullName,
} from '../../types';
import {
  discoverTerminalAssessments,
  DiscoveredTerminalContext,
} from '../../services/terminalAssessmentDiscovery';
import {
  calculateLearnerTerminalResults,
  calculateLearningAreaTerminalResult,
  calculateStreamTerminalSubjectAverages,
  LearningAreaTerminalResult,
  ContributingAssessmentRef,
  isUpperPrimaryTerminalContext,
  getUpperPrimaryCanonicalSubjects,
  getUpperPrimaryStandaloneSubjects,
  resolveUpperPrimaryTerminalSubjects,
  resolveContributingAssessmentsStructure,
} from '../../services/terminalResultsEngine';
import {
  TerminalLearnerRanking,
  AssessmentRankingSummary,
  LearnerCohortEntry,
  isJuniorSchoolEducationLevel,
  isRankableEducationLevel,
  calculateCohortTerminalRankings,
  calculateSingleLearnerRanking,
  calculateLearnerSubjectRanks,
  calculateCohortSubjectRanks,
  calculateCohortAssessmentRankings,
} from '../../services/terminalRankingEngine';
import {
  downloadSingleTerminalReportPDF,
  downloadBatchTerminalReportsPDF,
  TerminalReportPDFData,
} from '../../services/terminalReportPdfGenerator';
import { getLearnerReportSubjects } from '../../services/analysisEngine';
import { useAcademicSession } from '../../contexts/AcademicSessionContext';
import { getUserFriendlyErrorMessage } from '../../utils/errorUtils';
import {
  getActiveTeacher,
  getAccessibleClasses,
  getAccessibleStudents,
} from '../../utils/rbacUtils';
import { api, isUUID } from '../../lib/storage';
import { TerminalResultsTable } from './TerminalResultsTable';
import { TerminalResultsCard } from './TerminalResultsCard';
import { AssessmentTrailDrawer } from './AssessmentTrailDrawer';
import { TerminalReportModal } from './TerminalReportModal';
import { NextTermOpeningDateModal } from '../NextTermOpeningDateModal';
import { isGrade9Term3Report } from '../../services/nextTermOpeningDateResolver';
import { CbeTerminalMeritListReport } from './CbeTerminalMeritListReport';
import {
  generateTerminalMeritDataset,
  TerminalMeritListData,
  isLearnerInSelectedClassStream,
  resolveLearnerClassStream,
} from '../../services/terminalMeritListExporter';
import { getEducationLevelForGrade } from '../../types';

export interface FilterMeritAssessmentsParams {
  exams?: Examination[];
  viewingYear?: { year: number | string; id?: string } | null;
  viewingTerm?: { term_name?: string; id?: string } | null;
  meritGrade?: string;
  isStaff?: boolean;
  isProvisionalMode?: boolean;
  classes?: ClassStream[];
}

/**
 * Authoritatively matches an examination to the selected academic session term.
 * Conforms to CBE entity identity invariants:
 * 1. Matches e.term_id against viewingTerm.id when both values exist.
 * 2. Matches e.term against viewingTerm.term_name case-insensitively when both values exist.
 * 3. Preserves safe fallbacks for legacy records storing a term label instead of a UUID.
 * 4. Never treats a UUID as a human-readable term name.
 * 5. Rejects empty or missing term data (never matches every term).
 */
export function isExamMatchingTerm(
  exam: { term_id?: string; term?: string },
  viewingTerm: { id?: string; term_name?: string } | null | undefined
): boolean {
  if (!viewingTerm) return false;

  const vId = viewingTerm.id ? String(viewingTerm.id).trim() : '';
  const vName = viewingTerm.term_name ? String(viewingTerm.term_name).trim() : '';

  const eId = exam.term_id ? String(exam.term_id).trim() : '';
  const eName = exam.term ? String(exam.term).trim() : '';

  // Requirement 5: Do not allow an empty or missing term value to match every term
  if (!vId && !vName) return false;
  if (!eId && !eName) return false;

  const vIdIsUuid = isUUID(vId);
  const eIdIsUuid = isUUID(eId);

  // If both have UUIDs, authoritative UUID match is required
  if (vIdIsUuid && eIdIsUuid) {
    return vId.toLowerCase() === eId.toLowerCase();
  }

  // Requirement 1: Match e.term_id against viewingTerm.id when both values exist
  if (eId && vId && eId.toLowerCase() === vId.toLowerCase()) {
    return true;
  }

  // Requirement 2: Match e.term against viewingTerm.term_name, case-insensitively, when both values exist
  if (eName && vName && eName.toLowerCase() === vName.toLowerCase()) {
    return true;
  }

  // Requirement 3: Safe fallbacks for legacy records storing a term label instead of a UUID
  // (Requirement 4: Never treat a UUID as a human-readable term name)
  if (eId && !eIdIsUuid && vName && eId.toLowerCase() === vName.toLowerCase()) {
    return true;
  }

  if (vId && !vIdIsUuid && eName && vId.toLowerCase() === eName.toLowerCase()) {
    return true;
  }

  return false;
}

/**
 * Authoritatively filters contributing assessments for the Terminal Merit List cohort.
 * Fail-safe invariant: Never falls back to individual learner assessments or cross-cohort exams.
 * Returns only exams genuinely matching the academic year, term, grade/level, and approval status.
 */
export function filterMeritContributingAssessments({
  exams = [],
  viewingYear,
  viewingTerm,
  meritGrade,
  isStaff = false,
  isProvisionalMode = false,
  classes = [],
}: FilterMeritAssessmentsParams): ContributingAssessmentRef[] {
  if (!exams || exams.length === 0 || !viewingYear || !viewingTerm || !meritGrade) {
    return [];
  }
  const yearNum = typeof viewingYear.year === 'number' ? viewingYear.year : parseInt(String(viewingYear.year), 10);
  const yearId = viewingYear.id ? String(viewingYear.id).trim() : '';

  return (exams || []).filter((e) => {
    if (!isStaff || !isProvisionalMode) {
      if (e.status !== 'Approved' && (e as any).approval_status !== 'Approved') return false;
    } else {
      const st = e.status || (e as any).approval_status;
      if (st !== 'Approved' && st !== 'Provisional' && st !== 'Draft_Pending_Approval') return false;
    }

    const eYear = typeof e.year === 'number'
      ? e.year
      : (e.academic_year_id && !isUUID(e.academic_year_id)
          ? parseInt(e.academic_year_id, 10)
          : parseInt(String((e as any).academic_year), 10));
    const yearMatch = (e.academic_year_id && yearId && e.academic_year_id === yearId) ||
      (!isNaN(eYear) && !isNaN(yearNum) && eYear === yearNum);
    if (!yearMatch) return false;

    if (!isExamMatchingTerm(e, viewingTerm)) return false;

    const applicableClasses = e.applicable_classes || (e as any).applicable_classes || [];
    if (applicableClasses.length > 0) {
      const meritClasses = classes.filter(
        (c) => c.class_name.toLowerCase() === meritGrade.toLowerCase()
      );
      const isApplicable = meritClasses.some(
        (c) =>
          applicableClasses.includes(c.id) ||
          (c.stream_id && applicableClasses.includes(c.stream_id)) ||
          applicableClasses.includes(c.class_name)
      );
      if (!isApplicable) return false;
    }

    const targetClasses = (e as any).target_classes || [];
    const targetLevels = (e as any).target_levels || [];
    if (e.class_id && e.class_id !== 'all') {
      const clsMatch = classes.find((c) => c.id === e.class_id);
      if (clsMatch && clsMatch.class_name.toLowerCase() !== meritGrade.toLowerCase()) {
        return false;
      }
    }
    if (targetClasses.length > 0) {
      const match = targetClasses.some((tc: string) => {
        const tcLow = tc.toLowerCase();
        return tcLow.includes(meritGrade.toLowerCase()) || meritGrade.toLowerCase().includes(tcLow);
      });
      if (!match) return false;
    }
    if (targetLevels.length > 0) {
      const eduLevel = getEducationLevelForGrade(meritGrade);
      if (eduLevel && !targetLevels.includes(eduLevel)) return false;
    }
    if (e.education_level) {
      const eduLevel = getEducationLevelForGrade(meritGrade);
      if (eduLevel && e.education_level !== eduLevel) return false;
    }
    return true;
  }).map((e) => ({
    id: e.id,
    exam_name: e.exam_name || (e as any).title || (e as any).name || 'Assessment',
    title: (e as any).title || e.exam_name || (e as any).name || 'Assessment',
    status: e.status || 'Approved',
    date: (e as any).date || (e as any).start_date || e.created_at || '',
    max_marks: (e as any).max_marks || (e as any).max_score || (e as any).total_marks || 100,
    out_of: (e as any).out_of || (e as any).max_marks || (e as any).max_score || (e as any).total_marks || 100,
    maxScore: (e as any).max_score || (e as any).max_marks || (e as any).total_marks || 100,
    isOfficial: e.status === 'Approved',
    assessment_structure: e.assessment_structure,
    include_agriculture: e.include_agriculture,
  }));
}

function getStudentInitials(student: Student): string {
  const first = student.first_name?.trim() || '';
  const last = student.last_name?.trim() || '';
  if (first && last) {
    return `${first[0]}${last[0]}`.toUpperCase();
  }
  const full = getStudentFullName(student).trim();
  const parts = full.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
  }
  return (full.slice(0, 2) || 'ST').toUpperCase();
}

interface TerminalResultsViewProps {
  school: School;
  students: Student[];
  subjects: Subject[];
  exams?: Examination[];
  marks?: Mark[];
  grades: Grade[];
  classes: ClassStream[];
  teachers?: Teacher[];
  currentUser?: User;
  initialClassId?: string;
  initialStreamId?: string;
  initialStudentId?: string;
  initialViewMode?: 'individual' | 'merit_list';
}

export const TerminalResultsView: React.FC<TerminalResultsViewProps> = ({
  school,
  students = [],
  subjects = [],
  exams = [],
  marks = [],
  grades = [],
  classes = [],
  teachers = [],
  currentUser,
  initialClassId,
  initialStreamId,
  initialStudentId,
  initialViewMode,
}) => {
  // Authoritative Academic Session Context
  const { viewingYear, viewingTerm } = useAcademicSession();

  // Sub-navigation view mode: 'individual' vs 'merit_list'
  const [viewMode, setViewMode] = useState<'individual' | 'merit_list'>(
    initialViewMode || 'individual'
  );
  // Merit List stream filter: 'all' (General Grade View) or specific stream_id
  const [meritStreamId, setMeritStreamId] = useState<string>(
    initialStreamId || 'all'
  );

  // RBAC & Permission verification
  const isStaff =
    currentUser?.role === 'admin' ||
    currentUser?.role === 'class_teacher' ||
    currentUser?.role === 'subject_teacher';

  const activeTeacher = useMemo(
    () => getActiveTeacher(currentUser || null, teachers || []),
    [currentUser, teachers]
  );

  const accessibleClasses = useMemo(() => {
    return getAccessibleClasses(currentUser || null, activeTeacher, classes);
  }, [currentUser, activeTeacher, classes]);

  // Helper to resolve an incoming class ID or class name to authoritative stream_id || id
  const resolveClassStreamId = useCallback((targetClassId?: string, targetStreamId?: string): string => {
    if (!targetClassId && !targetStreamId) return '';
    // 1. Direct stream_id / id match
    if (targetClassId) {
      const match = accessibleClasses.find((c) => (c.stream_id || c.id) === targetClassId);
      if (match) return match.stream_id || match.id;
    }
    if (targetStreamId && targetStreamId !== 'all') {
      const match = accessibleClasses.find((c) => (c.stream_id || c.id) === targetStreamId);
      if (match) return match.stream_id || match.id;
    }
    // 2. Class name match (e.g. "Grade 9")
    if (targetClassId) {
      const candidates = accessibleClasses.filter(
        (c) => c.class_name.toLowerCase() === targetClassId.toLowerCase()
      );
      if (targetStreamId && targetStreamId !== 'all') {
        const streamMatch = candidates.find(
          (c) =>
            c.stream_id === targetStreamId ||
            c.id === targetStreamId ||
            c.stream.toLowerCase() === targetStreamId.toLowerCase()
        );
        if (streamMatch) return streamMatch.stream_id || streamMatch.id;
      }
      if (candidates.length === 1) {
        return candidates[0].stream_id || candidates[0].id;
      }
    }
    // Fail-closed: NEVER default to accessibleClasses[0] or PP1
    return '';
  }, [accessibleClasses]);

  // Context Selection States (Fail-closed: Defaults to empty when unselected or unmatched)
  const [selectedClassId, setSelectedClassId] = useState<string>(() => {
    return resolveClassStreamId(initialClassId, initialStreamId);
  });

  // Authoritatively sync when initialClassId or initialStreamId prop changes
  useEffect(() => {
    const resolved = resolveClassStreamId(initialClassId, initialStreamId);
    if (resolved && resolved !== selectedClassId) {
      setSelectedClassId(resolved);
    }
  }, [initialClassId, initialStreamId, resolveClassStreamId, selectedClassId]);

  const [selectedStudentId, setSelectedStudentId] = useState<string>(initialStudentId || '');
  const [isProvisionalMode, setIsProvisionalMode] = useState<boolean>(false);

  // Discovery & Calculation States
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [discoveryError, setDiscoveryError] = useState<string | null>(null);
  const [discoveredContext, setDiscoveredContext] = useState<DiscoveredTerminalContext | null>(null);
  const [learnerMarks, setLearnerMarks] = useState<Mark[]>([]);
  const [cohortMarks, setCohortMarks] = useState<Mark[]>([]);

  // Progressive Disclosure Trail Drawer State
  const [trailSubject, setTrailSubject] = useState<Subject | null>(null);
  const [trailResult, setTrailResult] = useState<LearningAreaTerminalResult | null>(null);
  const [isTrailOpen, setIsTrailOpen] = useState<boolean>(false);

  // Terminal Report Form & PDF Presentation States
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [hideSubComponents, setHideSubComponents] = useState<boolean>(false);
  const [isDownloadingSingle, setIsDownloadingSingle] = useState<boolean>(false);
  const [isBatchDownloading, setIsBatchDownloading] = useState<boolean>(false);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number } | null>(null);
  const [batchDownloadError, setBatchDownloadError] = useState<string | null>(null);
  const [dateModalConfig, setDateModalConfig] = useState<{
    isOpen: boolean;
    context: 'single' | 'batch';
    student?: Student;
  } | null>(null);

  // Selected Class Stream Object
  const selectedClassStream = useMemo(() => {
    if (!selectedClassId) return null;
    return (
      classes.find((c) => (c.stream_id || c.id) === selectedClassId) ||
      classes.find((c) => c.class_name === selectedClassId) ||
      null
    );
  }, [classes, selectedClassId]);

  // Accessible Learners for Selected Class & Stream (Strict Stream Isolation)
  const classStudents = useMemo(() => {
    if (!selectedClassStream) return [];
    return students.filter((s) => {
      const studentAny = s as any;
      const studentStream = typeof studentAny.stream === 'string' ? studentAny.stream : (studentAny.stream_name || '');
      const studentClassName =
        typeof studentAny.class_name === 'string' ? studentAny.class_name : (s.grade || '');

      // 1. Authoritative Stream Matching: When a specific stream_id exists
      if (selectedClassStream.stream_id) {
        if (s.stream_id === selectedClassStream.stream_id) return true;
        if (s.class_id === selectedClassStream.id && s.stream_id === selectedClassStream.stream_id) return true;
        if (
          selectedClassStream.stream &&
          studentStream &&
          studentStream.trim().toLowerCase() === selectedClassStream.stream.trim().toLowerCase() &&
          (!selectedClassStream.class_name || studentClassName.trim().toLowerCase() === selectedClassStream.class_name.trim().toLowerCase())
        ) {
          return true;
        }
      }

      // 2. Legacy / Named Stream Context: When selectedClassStream has a stream name but no stream_id
      if (selectedClassStream.stream && selectedClassStream.stream.trim() !== '') {
        const matchStreamId = s.stream_id === selectedClassStream.id;
        const matchExactName =
          Boolean(studentStream) &&
          studentStream.trim().toLowerCase() === selectedClassStream.stream.trim().toLowerCase() &&
          Boolean(studentClassName && selectedClassStream.class_name) &&
          studentClassName.trim().toLowerCase() === selectedClassStream.class_name.trim().toLowerCase();

        if (studentStream) {
          return matchExactName;
        }
        return matchStreamId;
      }

      // 3. Class-Only Context: Unstreamed class (e.g., PP1 with no streams)
      const matchClassId =
        s.class_id === selectedClassStream.id || s.stream_id === selectedClassStream.id;
      const matchClassName =
        Boolean(studentClassName && selectedClassStream.class_name) &&
        studentClassName.trim().toLowerCase() === selectedClassStream.class_name.trim().toLowerCase();

      return matchClassId || matchClassName;
    });
  }, [students, selectedClassStream]);

  // Fail-closed learner selection: preserve valid learner, clear if invalid after class/stream change
  useEffect(() => {
    if (selectedStudentId) {
      const isValid = classStudents.some((s) => s.id === selectedStudentId);
      if (!isValid) {
        if (initialStudentId && classStudents.some((s) => s.id === initialStudentId)) {
          setSelectedStudentId(initialStudentId);
        } else {
          setSelectedStudentId('');
        }
      }
    } else if (initialStudentId && classStudents.some((s) => s.id === initialStudentId)) {
      setSelectedStudentId(initialStudentId);
    }
  }, [classStudents, selectedStudentId, initialStudentId]);

  const selectedStudent = useMemo(() => {
    return students.find((s) => s.id === selectedStudentId) || null;
  }, [students, selectedStudentId]);

  // Up-to-date prop references to avoid triggering discovery resets on array reference changes
  const examsRef = useRef(exams);
  examsRef.current = exams;

  const marksRef = useRef(marks);
  marksRef.current = marks;

  const classesRef = useRef(classes);
  classesRef.current = classes;

  const studentsRef = useRef(students);
  studentsRef.current = students;

  // Request sequencing reference to prevent stale responses from overwriting newer selections
  const requestIdRef = useRef<number>(0);

  // Stable key of relevant exam metadata for the active session to detect genuine exam additions/status changes
  const relevantExamsKey = useMemo(() => {
    const yNum = typeof viewingYear?.year === 'number' ? viewingYear.year : parseInt(String(viewingYear?.year), 10);
    const yId = viewingYear?.id ? String(viewingYear.id).trim() : '';
    return (exams || [])
      .filter((e) => {
        const eYear = typeof e.year === 'number'
          ? e.year
          : (e.academic_year_id && !isUUID(e.academic_year_id)
              ? parseInt(e.academic_year_id, 10)
              : parseInt(String((e as any).academic_year), 10));
        const mYear = (e.academic_year_id && yId && e.academic_year_id === yId) ||
          (!isNaN(eYear) && !isNaN(yNum) && eYear === yNum);
        const mTerm = isExamMatchingTerm(e, viewingTerm);
        return mYear && mTerm;
      })
      .map((e) => `${e.id}:${e.status}:${e.start_date || ''}`)
      .sort()
      .join('|');
  }, [exams, viewingYear, viewingTerm]);

  // Discover Assessments & Calculate Results
  const loadTerminalResults = useCallback(async () => {
    if (!selectedStudent || !selectedClassStream || !viewingYear || !viewingTerm) {
      setDiscoveredContext(null);
      setLearnerMarks([]);
      return;
    }

    const currentRequestId = ++requestIdRef.current;
    setIsLoading(true);
    setDiscoveryError(null);

    try {
      const academicYearId = (viewingYear as any).id || String(viewingYear.year);
      const termId = (viewingTerm as any).id || String(viewingTerm.term_name || viewingTerm.id);

      // Authoritatively fetch the selected learner's marks from Supabase
      const fetchedMarks = await api.fetchMarksForLearner(selectedStudent.id);
      if (currentRequestId !== requestIdRef.current) return;
      setLearnerMarks(fetchedMarks);

      // Enforce strict learner scoping: candidate marks must ONLY belong to the selected learner
      const currentMarks = marksRef.current || [];
      const studentPropMarks = currentMarks.filter((m) => m.student_id === selectedStudent.id);
      const candidateMarks =
        fetchedMarks.length > 0 ? fetchedMarks : (studentPropMarks.length > 0 ? studentPropMarks : undefined);

      const discovered = await discoverTerminalAssessments({
        academicYearId,
        termId,
        student: selectedStudent,
        classStream: selectedClassStream,
        isProvisionalMode: isStaff ? isProvisionalMode : false, // Staff-only gating
        examinations: examsRef.current.length > 0 ? examsRef.current : undefined,
        marks: candidateMarks,
        classes: classesRef.current,
        allMarks: currentMarks,
        students: studentsRef.current,
      });

      if (currentRequestId !== requestIdRef.current) return;
      setDiscoveredContext(discovered);

      // Authoritatively fetch marks for the entire grade cohort for contributing assessments
      if (discovered && discovered.contributingAssessments && discovered.contributingAssessments.length > 0) {
        try {
          const examMarkPromises = discovered.contributingAssessments.map((a) =>
            api.fetchMarksForExam(a.id)
          );
          const examMarksArrays = await Promise.all(examMarkPromises);
          if (currentRequestId !== requestIdRef.current) return;
          const allFetchedCohortMarks = examMarksArrays.flat();
          setCohortMarks(allFetchedCohortMarks);
        } catch (fetchCohortErr) {
          console.warn('[TerminalResultsView] Failed to fetch cohort marks for exams:', fetchCohortErr);
        }
      } else {
        setCohortMarks([]);
      }
    } catch (err: any) {
      if (currentRequestId !== requestIdRef.current) return;
      console.error('[TerminalResultsView] Discovery error:', err);
      setDiscoveryError(getUserFriendlyErrorMessage(err, 'Failed to discover contributing assessments from database.'));
      setDiscoveredContext(null);
    } finally {
      if (currentRequestId === requestIdRef.current) {
        setIsLoading(false);
      }
    }
  }, [
    selectedStudent?.id,
    selectedClassStream?.stream_id || selectedClassStream?.id,
    (viewingYear as any)?.id || viewingYear?.year,
    (viewingTerm as any)?.id || viewingTerm?.term_name,
    isProvisionalMode,
    isStaff,
  ]);

  // Auto-reload when genuine discovery context changes occur
  useEffect(() => {
    loadTerminalResults();
  }, [loadTerminalResults, relevantExamsKey]);

  // Contributing Assessments
  const contributingAssessments: ContributingAssessmentRef[] = useMemo(() => {
    return discoveredContext?.contributingAssessments || [];
  }, [discoveredContext]);

  // Determine Upper Primary Context
  const isUpperPrimary = useMemo(() => {
    return isUpperPrimaryTerminalContext({
      classStream: selectedClassStream,
      student: selectedStudent,
      gradeName: selectedClassStream?.class_name || selectedStudent?.grade,
      educationLevel: selectedClassStream?.education_level || selectedStudent?.education_level,
      contributingAssessments,
      subjects,
    });
  }, [selectedClassStream, selectedStudent, contributingAssessments, subjects]);

  // Assessment Structure Resolution
  const contributingStructureInfo = useMemo(() => {
    return resolveContributingAssessmentsStructure(contributingAssessments);
  }, [contributingAssessments]);

  // Authoritative Learner-Scoped Applicable Subjects
  const applicableSubjects: Subject[] = useMemo(() => {
    if (!selectedStudent && !selectedClassStream) {
      return isUpperPrimary
        ? resolveUpperPrimaryTerminalSubjects(subjects, contributingAssessments)
        : subjects;
    }
    const rawScoped = getLearnerReportSubjects(
      selectedStudent || undefined,
      selectedClassStream || undefined,
      subjects,
      teachers
    );
    // Ensure strict uniqueness by Subject ID
    const seenIds = new Set<string>();
    const unique: Subject[] = [];
    for (const sb of rawScoped) {
      if (sb && sb.id && !seenIds.has(sb.id)) {
        seenIds.add(sb.id);
        unique.push(sb);
      }
    }
    const baseSubjects = unique.length > 0 ? unique : subjects;
    if (isUpperPrimary) {
      return resolveUpperPrimaryTerminalSubjects(baseSubjects, contributingAssessments);
    }
    return baseSubjects;
  }, [selectedStudent, selectedClassStream, subjects, teachers, isUpperPrimary, contributingAssessments]);

  // Learning Area Results Calculation Map
  const resultsBySubject: Map<string, LearningAreaTerminalResult> = useMemo(() => {
    if (!selectedStudent || contributingAssessments.length === 0) {
      return new Map();
    }

    const subjectIds = applicableSubjects.map((s) => s.id);
    const studentPropMarks = marks.filter((m) => m.student_id === selectedStudent.id);
    const discoveredMarks =
      studentPropMarks.length > 0
        ? studentPropMarks
        : (learnerMarks.length > 0
          ? learnerMarks
          : (discoveredContext?.marks && discoveredContext.marks.length > 0
            ? discoveredContext.marks
            : []));

    return calculateLearnerTerminalResults({
      learnerId: selectedStudent.id,
      subjectIds,
      contributingAssessments,
      marks: discoveredMarks,
      grades,
      educationLevel: selectedClassStream?.education_level || selectedStudent?.education_level,
      gradeName: selectedClassStream?.class_name || selectedStudent?.grade,
      subjects: subjects && subjects.length > 0 ? subjects : applicableSubjects,
      targetClass: selectedClassStream,
    });
  }, [selectedStudent, applicableSubjects, contributingAssessments, discoveredContext, learnerMarks, marks, grades, selectedClassStream]);

  // Learner Summary Metrics
  const summaryMetrics = useMemo(() => {
    let completeCount = 0;
    let incompleteCount = 0;

    for (const subject of applicableSubjects) {
      const res = resultsBySubject.get(subject.id);
      if (res?.isComplete) {
        completeCount++;
      } else {
        incompleteCount++;
      }
    }

    let upTotalMarks: number | null = 0;
    let upTotalPoints: number | null = 0;
    let upAllComplete = true;

    if (isUpperPrimary) {
      for (const subject of applicableSubjects) {
        const res = resultsBySubject.get(subject.id);
        if (res && res.isComplete && typeof res.terminalPercentage === 'number') {
          upTotalMarks = (upTotalMarks ?? 0) + res.terminalPercentage;
          upTotalPoints = (upTotalPoints ?? 0) + (res.points ?? 0);
        } else {
          upAllComplete = false;
        }
      }
      if (!upAllComplete) {
        upTotalMarks = null;
        upTotalPoints = null;
      }
    }

    return {
      totalSubjects: applicableSubjects.length,
      completeCount,
      incompleteCount,
      assessmentCount: contributingAssessments.length,
      isUpperPrimary,
      upTotalMarks,
      upTotalMax: applicableSubjects.length * 100,
      upTotalPoints,
      upPointsMax: applicableSubjects.length * 4,
      upMeanScore:
        upTotalMarks !== null && applicableSubjects.length > 0
          ? Math.round((upTotalMarks / applicableSubjects.length) * 10) / 10
          : null,
    };
  }, [applicableSubjects, resultsBySubject, contributingAssessments, isUpperPrimary]);

  // Determine Junior School Education Level Authority
  const isJuniorSchool = useMemo(() => {
    return isJuniorSchoolEducationLevel(undefined, selectedClassStream, selectedStudent);
  }, [selectedClassStream, selectedStudent]);

  // Grade Cohort for Class-level and Stream-level Ranking
  const gradeStudents = useMemo(() => {
    if (!selectedClassStream && !selectedStudent) return [];
    const targetGrade = (selectedClassStream?.class_name || selectedStudent?.grade || '').trim().toLowerCase();
    if (!targetGrade) return classStudents;
    return students.filter((s) => {
      const g = (s.grade || (s as any).class_name || '').trim().toLowerCase();
      return g === targetGrade || g.replace(/^grade\s+/i, '') === targetGrade.replace(/^grade\s+/i, '');
    });
  }, [students, selectedClassStream, selectedStudent, classStudents]);

  // Unified Grade Cohort Entries for Authoritative Ranking & Subject Ranking
  const gradeCohortEntries = useMemo<LearnerCohortEntry[]>(() => {
    if (contributingAssessments.length === 0) return [];

    const entries: LearnerCohortEntry[] = [];

    for (const st of gradeStudents) {
      const isSelected = selectedStudent && st.id === selectedStudent.id;
      const stStreamName = (st as any).stream || (st as any).stream_name || '';
      const stClassName = (st as any).class_name || st.grade || '';

      const stClass =
        (st.stream_id ? classes.find((c) => c.stream_id === st.stream_id) : undefined) ||
        (stStreamName
          ? classes.find(
              (c) =>
                c.class_name.toLowerCase() === stClassName.toLowerCase() &&
                c.stream &&
                c.stream.toLowerCase() === String(stStreamName).toLowerCase()
            )
          : undefined) ||
        (st.stream_id ? classes.find((c) => c.id === st.stream_id) : undefined) ||
        classes.find((c) => c.id === st.class_id && (!c.stream || c.stream.toLowerCase() === String(stStreamName).toLowerCase())) ||
        classes.find((c) => c.id === st.class_id && !c.stream) ||
        (selectedClassStream &&
         selectedClassStream.class_name.toLowerCase() === stClassName.toLowerCase() &&
         (!selectedClassStream.stream || selectedClassStream.stream.toLowerCase() === String(stStreamName).toLowerCase())
          ? selectedClassStream
          : undefined);

      const rawScoped = getLearnerReportSubjects(st, stClass || selectedClassStream, subjects, teachers);
      const seenIds = new Set<string>();
      const uniqueSubjs: Subject[] = [];
      for (const sb of rawScoped) {
        if (sb && sb.id && !seenIds.has(sb.id)) {
          seenIds.add(sb.id);
          uniqueSubjs.push(sb);
        }
      }
        const isStUp = isUpperPrimaryTerminalContext({
          classStream: stClass || selectedClassStream,
          student: st,
          gradeName: (stClass || selectedClassStream)?.class_name || st.grade,
          educationLevel: (stClass || selectedClassStream)?.education_level || st.education_level,
          contributingAssessments,
          subjects,
        });

        const stSubjects = isStUp
          ? resolveUpperPrimaryTerminalSubjects(uniqueSubjs.length > 0 ? uniqueSubjs : subjects, contributingAssessments)
          : (uniqueSubjs.length > 0 ? uniqueSubjs : (applicableSubjects.length > 0 ? applicableSubjects : subjects));

        let stResults: Map<string, LearningAreaTerminalResult>;

        if (isSelected && resultsBySubject.size > 0) {
          stResults = resultsBySubject;
        } else {
          // Collect all available marks for this learner across sources (prioritizing live marks from props)
          const candidateMarks = [
            ...marks.filter((m) => m.student_id === st.id),
            ...learnerMarks.filter((m) => m.student_id === st.id),
            ...cohortMarks.filter((m) => m.student_id === st.id),
          ];

          // Deduplicate marks
          const seenMarkKeys = new Set<string>();
          const deduplicatedMarks: Mark[] = [];
          for (const m of candidateMarks) {
            const key = m.id || `${m.exam_id}_${m.subject_id}`;
            if (!seenMarkKeys.has(key)) {
              seenMarkKeys.add(key);
              deduplicatedMarks.push(m);
            }
          }

          stResults = calculateLearnerTerminalResults({
            learnerId: st.id,
            subjectIds: stSubjects.map((s) => s.id),
            contributingAssessments,
            marks: deduplicatedMarks,
            grades,
            educationLevel: (stClass || selectedClassStream)?.education_level || st.education_level,
            gradeName: (stClass || selectedClassStream)?.class_name || st.grade,
            subjects: subjects && subjects.length > 0 ? subjects : stSubjects,
          });
        }

      entries.push({
        student: {
          ...st,
          stream_id: stClass?.stream_id || st.stream_id,
          stream: stClass?.stream || stStreamName || (st as any).stream,
        } as Student,
        classStream: stClass,
        applicableSubjects: stSubjects,
        resultsBySubject: stResults,
      });
    }

    return entries;
  }, [
    gradeStudents,
    selectedStudent,
    selectedClassStream,
    classes,
    subjects,
    teachers,
    applicableSubjects,
    resultsBySubject,
    cohortMarks,
    learnerMarks,
    marks,
    contributingAssessments,
    grades,
  ]);

  // Authoritative Cohort Ranking Map for Junior School and Upper Primary
  const cohortRankings = useMemo(() => {
    if ((!isJuniorSchool && !isUpperPrimary) || gradeCohortEntries.length === 0) {
      return new Map<string, TerminalLearnerRanking>();
    }

    return calculateCohortTerminalRankings({
      learners: gradeCohortEntries,
      isProvisionalMode,
    });
  }, [isJuniorSchool, isUpperPrimary, gradeCohortEntries, isProvisionalMode]);

  const selectedLearnerRanking: TerminalLearnerRanking | null = useMemo(() => {
    if (!selectedStudent || (!isJuniorSchool && !isUpperPrimary)) return null;
    return (
      cohortRankings.get(selectedStudent.id) ||
      calculateSingleLearnerRanking({
        student: selectedStudent,
        classStream: selectedClassStream,
        resultsBySubject,
        applicableSubjects,
        cohortLearners: gradeCohortEntries,
        isProvisionalMode,
      })
    );
  }, [selectedStudent, isJuniorSchool, isUpperPrimary, cohortRankings, selectedClassStream, resultsBySubject, applicableSubjects, gradeCohortEntries, isProvisionalMode]);

  // Authoritative Subject Ranks for the selected learner across the grade cohort
  const learnerSubjectRanks = useMemo(() => {
    if (!selectedStudent || !applicableSubjects.length || gradeCohortEntries.length === 0) return {};
    return calculateLearnerSubjectRanks({
      learnerId: selectedStudent.id,
      applicableSubjects,
      cohortLearners: gradeCohortEntries,
    });
  }, [selectedStudent, applicableSubjects, gradeCohortEntries]);

  // Authoritative Assessment-Specific Ranks & Totals across contributing assessments
  const cohortAssessmentRankings = useMemo(() => {
    if (!gradeCohortEntries.length || !contributingAssessments.length || !applicableSubjects.length) {
      return new Map<string, Record<string, AssessmentRankingSummary>>();
    }
    return calculateCohortAssessmentRankings({
      contributingAssessments,
      applicableSubjects,
      cohortLearners: gradeCohortEntries,
      classes,
      isProvisionalMode,
    });
  }, [gradeCohortEntries, contributingAssessments, applicableSubjects, classes, isProvisionalMode]);

  const selectedLearnerAssessmentRankings = useMemo(() => {
    if (!selectedStudent) return undefined;
    return cohortAssessmentRankings.get(selectedStudent.id);
  }, [selectedStudent, cohortAssessmentRankings]);

  // Stream cohort grouping key helper (matching authoritative terminalRankingEngine logic)
  const getStreamKey = useCallback((student: Student, classStream?: ClassStream | null): string => {
    const rawGrade = (classStream?.class_name || student.grade || 'UnknownGrade').trim().toLowerCase();
    const gradeKey = rawGrade.replace(/^grade\s+/i, 'grade ');

    const studentStreamText = ((student as any).stream || (student as any).stream_name || '').trim();
    const classStreamText = (classStream?.stream || (classStream as any)?.stream_name || '').trim();

    const resolvedStream =
      (student.stream_id && student.stream_id.trim() !== '' ? student.stream_id : undefined) ||
      (classStream?.stream_id && classStream.stream_id.trim() !== '' ? classStream.stream_id : undefined) ||
      (studentStreamText !== '' ? `${gradeKey}_${studentStreamText}` : undefined) ||
      (classStreamText !== '' ? `${gradeKey}_${classStreamText}` : undefined) ||
      student.class_id ||
      classStream?.id ||
      'UnassignedStream';
    return String(resolvedStream).trim().toLowerCase();
  }, []);

  // Authoritative Stream Cohort Subject Averages for Junior School
  const cohortStreamSubjectAverages = useMemo(() => {
    const streamMap = new Map<string, Record<string, number | null>>();
    if (!isJuniorSchool || gradeCohortEntries.length === 0 || applicableSubjects.length === 0) {
      return streamMap;
    }

    // Group gradeCohortEntries by streamKey
    const groupedByStream = new Map<string, LearnerCohortEntry[]>();
    for (const entry of gradeCohortEntries) {
      const sKey = getStreamKey(entry.student, entry.classStream);
      const group = groupedByStream.get(sKey) || [];
      group.push(entry);
      groupedByStream.set(sKey, group);
    }

    // Calculate averages strictly for each stream cohort using the Phase 3A helper
    groupedByStream.forEach((streamEntries, sKey) => {
      const averages = calculateStreamTerminalSubjectAverages(
        streamEntries.map((e) => ({
          studentId: e.student.id,
          student: e.student,
          resultsBySubject: e.resultsBySubject,
        })),
        applicableSubjects
      );
      streamMap.set(sKey, averages);
    });

    return streamMap;
  }, [isJuniorSchool, gradeCohortEntries, applicableSubjects, getStreamKey]);

  const selectedLearnerStreamSubjectAverages = useMemo(() => {
    if (!selectedStudent || !isJuniorSchool) return undefined;
    const sKey = getStreamKey(selectedStudent, selectedClassStream);
    const cached = cohortStreamSubjectAverages.get(sKey);
    if (cached) return cached;

    const streamEntries = gradeCohortEntries.filter(
      (e) => getStreamKey(e.student, e.classStream) === sKey
    );
    if (streamEntries.length === 0) return undefined;

    return calculateStreamTerminalSubjectAverages(
      streamEntries.map((e) => ({
        studentId: e.student.id,
        student: e.student,
        resultsBySubject: e.resultsBySubject,
      })),
      applicableSubjects
    );
  }, [selectedStudent, isJuniorSchool, selectedClassStream, getStreamKey, cohortStreamSubjectAverages, gradeCohortEntries, applicableSubjects]);

  // Single Learner Report Download
  const executeSinglePDFDownload = async (confirmedDate: string) => {
    if (!selectedStudent || !selectedClassStream || contributingAssessments.length === 0) {
      return;
    }
    try {
      setIsDownloadingSingle(true);
      await new Promise((resolve) => setTimeout(resolve, 50));
      await downloadSingleTerminalReportPDF({
        student: selectedStudent,
        school,
        classStream: selectedClassStream,
        classes,
        academicYear: viewingYear?.year || 2026,
        term: viewingTerm?.term_name || 'Term 1',
        isProvisionalMode,
        contributingAssessments,
        subjects: applicableSubjects,
        resultsBySubject,
        grades,
        teachers,
        nextTermOpeningDate: confirmedDate || undefined,
        ranking: selectedLearnerRanking || undefined,
        assessmentRankings: selectedLearnerAssessmentRankings,
        subjectRanks: learnerSubjectRanks,
        hideSubComponents,
        streamSubjectAverages: selectedLearnerStreamSubjectAverages,
      });
    } catch (err) {
      console.error('Failed to download terminal report PDF:', err);
    } finally {
      setIsDownloadingSingle(false);
    }
  };

  const handleDownloadSinglePDF = async () => {
    if (!selectedStudent || !selectedClassStream || contributingAssessments.length === 0) {
      return;
    }

    if (
      isGrade9Term3Report({
        student: selectedStudent,
        classStream: selectedClassStream,
        classes,
        grade: selectedClassStream.class_name || selectedStudent.grade,
        term: viewingTerm?.term_name,
      })
    ) {
      executeSinglePDFDownload('');
      return;
    }

    setDateModalConfig({
      isOpen: true,
      context: 'single',
      student: selectedStudent,
    });
  };

  // Batch Stream Reports Download
  const executeBatchPDFDownload = async (confirmedDate: string) => {
    if (!selectedClassStream || classStudents.length === 0 || contributingAssessments.length === 0) {
      return;
    }
    try {
      setIsBatchDownloading(true);
      setBatchDownloadError(null);
      setBatchProgress({ current: 0, total: classStudents.length });
      await new Promise((resolve) => setTimeout(resolve, 50));

      const allReportsData: TerminalReportPDFData[] = [];

      // Step 1: Retrieve authoritative marks for this cohort without network waterfalls
      const studentIds = classStudents.map((s) => s.id).filter(Boolean);
      const studentIdSet = new Set(studentIds);
      const examIdSet = new Set(contributingAssessments.map((a) => a.id));
      const streamMarksMap = new Map<string, Mark[]>();

      // Check candidate in-memory marks (from cohortMarks discovered earlier or marks prop)
      const candidateInMemoryMarks = [
        ...(cohortMarks || []),
        ...(marks || []),
      ];

      const hasCompleteInMemoryMarks =
        contributingAssessments.length > 0 &&
        contributingAssessments.every((a) =>
          candidateInMemoryMarks.some((m) => m.exam_id === a.id)
        );

      if (hasCompleteInMemoryMarks) {
        // Pre-populate streamMarksMap directly from verified in-memory marks
        studentIds.forEach((sId) => streamMarksMap.set(sId, []));
        for (const m of candidateInMemoryMarks) {
          if (m.student_id && studentIdSet.has(m.student_id) && m.exam_id && examIdSet.has(m.exam_id)) {
            const list = streamMarksMap.get(m.student_id);
            if (list && !list.some((existing) => existing.id === m.id)) {
              list.push(m);
            }
          }
        }
      } else {
        // If in-memory marks are not complete, prefer the supported batch-query API
        try {
          if (typeof api.fetchMarksForWorkflow === 'function' && studentIds.length > 0) {
            studentIds.forEach((sId) => streamMarksMap.set(sId, []));
            const batchWorkflowMarks = await api.fetchMarksForWorkflow({
              studentIds,
            });
            if (Array.isArray(batchWorkflowMarks)) {
              for (const m of batchWorkflowMarks) {
                if (m.student_id && streamMarksMap.has(m.student_id)) {
                  streamMarksMap.get(m.student_id)!.push(m);
                }
              }
            }
          }
        } catch (batchErr) {
          console.warn('[TerminalResultsView] Scoped batch marks fetch failed, falling back to bounded concurrency learner queries:', batchErr);
          streamMarksMap.clear();
        }

        // Bounded concurrency fallback (concurrency of 5) for any missing learners
        const missingStudents = classStudents.filter((st) => !streamMarksMap.has(st.id));
        if (missingStudents.length > 0) {
          const CONCURRENCY_LIMIT = 5;
          for (let i = 0; i < missingStudents.length; i += CONCURRENCY_LIMIT) {
            const chunk = missingStudents.slice(i, i + CONCURRENCY_LIMIT);
            await Promise.all(
              chunk.map(async (st) => {
                try {
                  const fetched = await api.fetchMarksForLearner(st.id);
                  const validMarks = Array.isArray(fetched)
                    ? fetched.filter((m) => m.student_id === st.id)
                    : [];
                  streamMarksMap.set(st.id, validMarks);
                } catch (fetchErr: any) {
                  console.error(`[TerminalResultsView] Authoritative mark retrieval failed for learner ${st.id}:`, fetchErr);
                  throw new Error(
                    `Failed to retrieve authoritative marks from database for learner ${getStudentFullName(st)} (${st.admission_number || st.id}): ${fetchErr?.message || 'Database error'}. Batch generation aborted.`
                  );
                }
              })
            );
          }
        }
      }

      // Step 2: For each learner in classStudents, retrieve their authoritative marks and calculate terminal results
      for (let idx = 0; idx < classStudents.length; idx++) {
        const st = classStudents[idx];
        setBatchProgress({ current: idx + 1, total: classStudents.length });

        let stMarks: Mark[] = [];

        // If this learner is the currently selected student and we already have their authoritative marks loaded
        if (selectedStudent && st.id === selectedStudent.id && learnerMarks.length > 0) {
          stMarks = learnerMarks.filter((m) => m.student_id === st.id);
        } else if (streamMarksMap.has(st.id)) {
          stMarks = streamMarksMap.get(st.id)!;
        } else {
          try {
            const fetched = await api.fetchMarksForLearner(st.id);
            if (Array.isArray(fetched)) {
              stMarks = fetched.filter((m) => m.student_id === st.id);
              streamMarksMap.set(st.id, stMarks);
            }
          } catch (fetchErr: any) {
            console.error(`[TerminalResultsView] Authoritative mark retrieval failed for learner ${st.id}:`, fetchErr);
            throw new Error(
              `Failed to retrieve authoritative marks from database for learner ${getStudentFullName(st)} (${st.admission_number || st.id}): ${fetchErr?.message || 'Database error'}. Batch generation aborted.`
            );
          }
        }

        // Supplement from in-memory marks prop if still empty and marks prop contains entries for this learner
        if (stMarks.length === 0 && marks && marks.length > 0) {
          const propMarks = marks.filter((m) => m.student_id === st.id);
          if (propMarks.length > 0) {
            stMarks = propMarks;
          }
        }

        // STRICT IDENTITY VALIDATION:
        // Guarantee every mark belongs strictly to this learner's UUID
        stMarks = stMarks.filter((m) => m.student_id === st.id);

        const rawScoped = getLearnerReportSubjects(st, selectedClassStream, subjects, teachers);
        const seenIds = new Set<string>();
        const uniqueSubjs: Subject[] = [];
        for (const sb of rawScoped) {
          if (sb && sb.id && !seenIds.has(sb.id)) {
            seenIds.add(sb.id);
            uniqueSubjs.push(sb);
          }
        }
        const isStUp = isUpperPrimaryTerminalContext({
          classStream: selectedClassStream,
          student: st,
          gradeName: selectedClassStream?.class_name || st.grade,
          educationLevel: selectedClassStream?.education_level || st.education_level,
          contributingAssessments,
          subjects,
        });

        const stSubjects = isStUp
          ? resolveUpperPrimaryTerminalSubjects(uniqueSubjs.length > 0 ? uniqueSubjs : subjects, contributingAssessments)
          : (uniqueSubjs.length > 0 ? uniqueSubjs : subjects);

        const stResultsMap = calculateLearnerTerminalResults({
          learnerId: st.id,
          subjectIds: stSubjects.map((s) => s.id),
          contributingAssessments,
          marks: stMarks,
          grades,
          educationLevel: selectedClassStream?.education_level || st.education_level,
          gradeName: selectedClassStream?.class_name || st.grade,
          subjects: stSubjects,
        });

        allReportsData.push({
          student: st,
          school,
          classStream: selectedClassStream,
          classes,
          academicYear: viewingYear?.year || 2026,
          term: viewingTerm?.term_name || 'Term 1',
          isProvisionalMode,
          contributingAssessments,
          subjects: stSubjects,
          resultsBySubject: stResultsMap,
          grades,
          teachers,
          nextTermOpeningDate: confirmedDate || undefined,
          hideSubComponents,
        });
      }

      // Pre-compute cohort rankings for batch reports if Junior School (using full grade cohort)
      const batchCohortEntries: LearnerCohortEntry[] = allReportsData.map((r) => ({
        student: r.student,
        classStream: r.classStream,
        applicableSubjects: r.subjects,
        resultsBySubject: r.resultsBySubject,
      }));

      const fullCohortForBatch = gradeCohortEntries.length > 0 ? gradeCohortEntries : batchCohortEntries;

      if (isRankableEducationLevel(undefined, selectedClassStream) || isUpperPrimary) {
        const batchRankingsMap = calculateCohortTerminalRankings({
          learners: fullCohortForBatch,
          isProvisionalMode,
        });

        for (const r of allReportsData) {
          r.ranking = batchRankingsMap.get(r.student.id) || cohortRankings.get(r.student.id) || calculateSingleLearnerRanking({
            student: r.student,
            classStream: r.classStream,
            resultsBySubject: r.resultsBySubject,
            applicableSubjects: r.subjects,
            cohortLearners: fullCohortForBatch,
            isProvisionalMode,
          });
        }
      }

      // Pre-compute subject ranks for batch reports using authoritative ranking engine
      const cohortSubjectRanksMap = calculateCohortSubjectRanks({
        applicableSubjects,
        cohortLearners: fullCohortForBatch,
      });

      const cohortAssessmentRankingsMap = calculateCohortAssessmentRankings({
        contributingAssessments,
        applicableSubjects,
        cohortLearners: fullCohortForBatch,
        isProvisionalMode,
      });

      for (const r of allReportsData) {
        r.subjectRanks = cohortSubjectRanksMap.get(r.student.id) || {};
        r.assessmentRankings = cohortAssessmentRankingsMap.get(r.student.id) || {};
        if (isJuniorSchool) {
          const sKey = getStreamKey(r.student, r.classStream);
          let streamAvgs = cohortStreamSubjectAverages.get(sKey);
          if (!streamAvgs) {
            const streamEntries = fullCohortForBatch.filter(
              (e) => getStreamKey(e.student, e.classStream) === sKey
            );
            streamAvgs = calculateStreamTerminalSubjectAverages(
              streamEntries.map((e) => ({
                studentId: e.student.id,
                student: e.student,
                resultsBySubject: e.resultsBySubject,
              })),
              r.subjects
            );
          }
          r.streamSubjectAverages = streamAvgs;
        }
      }

      await downloadBatchTerminalReportsPDF(allReportsData, (current, total) => {
        setBatchProgress({ current, total });
      });
    } catch (err: any) {
      console.error('Failed to batch download terminal reports PDF:', err);
      setBatchDownloadError(getUserFriendlyErrorMessage(err, 'Failed to generate batch terminal reports PDF.'));
    } finally {
      setIsBatchDownloading(false);
      setBatchProgress(null);
    }
  };

  const handleBatchDownloadPDF = async () => {
    if (!selectedClassStream || classStudents.length === 0 || contributingAssessments.length === 0) {
      return;
    }

    if (
      isGrade9Term3Report({
        classStream: selectedClassStream,
        classes,
        grade: selectedClassStream.class_name || classStudents[0]?.grade,
        term: viewingTerm?.term_name,
      })
    ) {
      executeBatchPDFDownload('');
      return;
    }

    setDateModalConfig({
      isOpen: true,
      context: 'batch',
    });
  };

  // --- Terminal Merit List Computation ---
  // Active Grade for Merit List mode: derived from selectedClassStream, or fallback to first accessible class grade
  const [meritGrade, setMeritGrade] = useState<string>(() => {
    return selectedClassStream?.class_name || (accessibleClasses.length > 0 ? accessibleClasses[0].class_name : '');
  });

  // Keep meritGrade in sync when selectedClassStream changes
  useEffect(() => {
    if (selectedClassStream?.class_name && selectedClassStream.class_name !== meritGrade) {
      setMeritGrade(selectedClassStream.class_name);
    }
  }, [selectedClassStream, meritGrade]);

  // Unique accessible grades
  const accessibleGrades = useMemo(() => {
    const seen = new Set<string>();
    const list: string[] = [];
    for (const c of accessibleClasses) {
      if (c.class_name && !seen.has(c.class_name)) {
        seen.add(c.class_name);
        list.push(c.class_name);
      }
    }
    return list;
  }, [accessibleClasses]);

  // Available streams for current merit grade
  const gradeStreams = useMemo(() => {
    if (!meritGrade) return [];
    return accessibleClasses.filter(
      (c) => c.class_name.toLowerCase() === meritGrade.toLowerCase()
    );
  }, [accessibleClasses, meritGrade]);

  // Contributing assessments for Terminal Merit List (Fail-safe: scoped strictly to cohort, no cross-context fallback)
  const meritContributingAssessments = useMemo(() => {
    return filterMeritContributingAssessments({
      exams,
      viewingYear,
      viewingTerm,
      meritGrade,
      isStaff,
      isProvisionalMode,
      classes,
    });
  }, [exams, viewingYear, viewingTerm, meritGrade, isStaff, isProvisionalMode, classes]);

  // Supabase Cohort Marks Fetching for Terminal Merit List
  const [meritSupabaseMarks, setMeritSupabaseMarks] = useState<Mark[]>([]);
  const [isMeritLoading, setIsMeritLoading] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    if (viewMode !== 'merit_list' || !meritGrade) return;

    const cohortStudents = students.filter((s) => {
      const sGrade = s.grade || (s as any).class_name || '';
      if (sGrade.toLowerCase() !== meritGrade.toLowerCase()) return false;
      if (meritStreamId && meritStreamId !== 'all') {
        const targetStream = gradeStreams.find((c) => (c.stream_id || c.id) === meritStreamId) || selectedClassStream;
        return isLearnerInSelectedClassStream(s, targetStream);
      }
      return true;
    });

    const studentIds = cohortStudents.map((s) => s.id).filter(Boolean);
    if (studentIds.length === 0) {
      setMeritSupabaseMarks([]);
      return;
    }

    setIsMeritLoading(true);
    (async () => {
      try {
        if (typeof api.fetchMarksForWorkflow === 'function') {
          // Batch fetch in chunks of 30 student IDs for complete data accuracy across large cohorts
          const CHUNK_SIZE = 30;
          const allFetchedMarks: Mark[] = [];
          for (let i = 0; i < studentIds.length; i += CHUNK_SIZE) {
            const chunk = studentIds.slice(i, i + CHUNK_SIZE);
            const fetchedChunk = await api.fetchMarksForWorkflow({ studentIds: chunk });
            if (Array.isArray(fetchedChunk)) {
              allFetchedMarks.push(...fetchedChunk);
            }
          }
          if (isMounted) {
            setMeritSupabaseMarks(allFetchedMarks);
          }
        }
      } catch (err) {
        console.error('[TerminalResultsView] Supabase merit list marks query error:', err);
      } finally {
        if (isMounted) setIsMeritLoading(false);
      }
    })();

    return () => {
      isMounted = false;
    };
  }, [viewMode, meritGrade, meritStreamId, students, gradeStreams, classes, viewingYear, viewingTerm]);

  // Generate Terminal Merit List Dataset
  const meritListData: TerminalMeritListData | null = useMemo(() => {
    if (!meritGrade || !viewingYear || !viewingTerm) return null;
    if (meritContributingAssessments.length === 0) return null;

    const yearNum = typeof viewingYear.year === 'number' ? viewingYear.year : parseInt(String(viewingYear.year), 10);

    // Filter cohort students for merit list
    const cohortStudents = students.filter((s) => {
      // Respect established learner eligibility rules: inactive and future learners excluded
      if (s.active === false || s.enrolment_status === 'inactive' || s.enrolment_status === 'future') {
        return false;
      }

      // Intake year & term relative to academic year
      if (s.intake_year) {
        if (s.intake_year > yearNum) return false;
        if (s.intake_year === yearNum && s.intake_term && viewingTerm?.term_name) {
          const termOrder: Record<string, number> = { 'Term 1': 1, 'Term 2': 2, 'Term 3': 3 };
          const intakeNum = termOrder[s.intake_term] || 1;
          const currentTermNum = termOrder[viewingTerm.term_name] || 1;
          if (intakeNum > currentTermNum) return false;
        }
      }

      // Authoritative grade resolution via class/stream relationship, fallback to stored grade
      const stClass = resolveLearnerClassStream(s, classes);
      const sGrade = stClass?.class_name || s.grade || (s as any).class_name || '';
      if (sGrade.toLowerCase() !== meritGrade.toLowerCase()) return false;

      if (meritStreamId && meritStreamId !== 'all') {
        const targetStream = gradeStreams.find((c) => (c.stream_id || c.id) === meritStreamId);
        if (!targetStream) return false;
        return isLearnerInSelectedClassStream(s, targetStream);
      }
      return true;
    });

    if (cohortStudents.length === 0) return null;

    // Map candidate marks for all cohort learners (preferring live Supabase fetched marks)
    const effectiveMarksMap = new Map<string, Mark>();
    for (const m of (marks || [])) {
      if (m.id) effectiveMarksMap.set(m.id, m);
    }
    for (const m of meritSupabaseMarks) {
      if (m.id) effectiveMarksMap.set(m.id, m);
    }
    const combinedMarks = Array.from(effectiveMarksMap.values());

    // Authoritative contributing assessments scoped strictly to the selected academic year, term, grade, and approval rules
    const effectiveContributing = meritContributingAssessments;

    const marksByLearner = new Map<string, Mark[]>();
    for (const st of cohortStudents) {
      const stMarks = combinedMarks.filter((m) => m.student_id === st.id);
      marksByLearner.set(st.id, stMarks);
    }

    // Compute resultsBySubject for each learner
    const learnerResultsMap = new Map<string, Map<string, LearningAreaTerminalResult>>();
    for (const st of cohortStudents) {
      const stClass = resolveLearnerClassStream(st, classes) || (gradeStreams.length > 0 ? gradeStreams[0] : undefined);
      const isStUp = isUpperPrimaryTerminalContext({
        classStream: stClass,
        student: st,
        gradeName: stClass?.class_name || meritGrade,
        educationLevel: stClass?.education_level || getEducationLevelForGrade(meritGrade),
        contributingAssessments: effectiveContributing,
        subjects,
      });
      const rawSubjects = getLearnerReportSubjects(st, stClass, subjects, teachers);
      const stSubjects = isStUp
        ? resolveUpperPrimaryTerminalSubjects(rawSubjects.length > 0 ? rawSubjects : subjects, effectiveContributing)
        : rawSubjects;
      const stMarks = marksByLearner.get(st.id) || [];
      const stResults = calculateLearnerTerminalResults({
        learnerId: st.id,
        subjectIds: stSubjects.map((s) => s.id),
        contributingAssessments: effectiveContributing,
        marks: stMarks,
        grades,
        educationLevel: stClass?.education_level || getEducationLevelForGrade(meritGrade),
        gradeName: meritGrade,
        subjects: stSubjects,
      });
      learnerResultsMap.set(st.id, stResults);
    }

    return generateTerminalMeritDataset({
      school,
      academicYear: yearNum,
      term: viewingTerm?.term_name || 'Term 1',
      grade: meritGrade,
      selectedStreamId: meritStreamId,
      classes,
      students,
      subjects,
      teachers,
      grades,
      isProvisionalMode: isStaff ? isProvisionalMode : false,
      learnerResultsMap,
      contributingAssessments: effectiveContributing,
    });
  }, [
    meritGrade,
    viewingYear,
    viewingTerm,
    meritStreamId,
    students,
    gradeStreams,
    meritContributingAssessments,
    marks,
    meritSupabaseMarks,
    classes,
    selectedClassStream,
    subjects,
    teachers,
    grades,
    school,
    isStaff,
    isProvisionalMode,
  ]);

  // Handle open trail
  const handleOpenTrail = (subject: Subject, result: LearningAreaTerminalResult) => {
    setTrailSubject(subject);
    setTrailResult(result);
    setIsTrailOpen(true);
  };

  const handleCloseTrail = () => {
    setIsTrailOpen(false);
    setTrailSubject(null);
    setTrailResult(null);
  };

  return (
    <div id="terminal-results-view" className="space-y-5">
      {/* 1. Context Controls Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        {/* Top Header Row: Title & Subtitle + Action Badge & Refresh */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center text-[#176B45] dark:text-emerald-400 shrink-0 shadow-2xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 leading-tight">
                Terminal Results Orchestrator
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium hidden sm:block">
                View individual learner report cards & cohort terminal merit lists
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 self-end sm:self-auto">
            <div className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 whitespace-nowrap border border-slate-200/70 dark:border-slate-700/70 shadow-2xs">
              <span>{viewingYear?.year || '2026'}</span>
              <span className="text-slate-400 dark:text-slate-500">·</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">{viewingTerm?.term_name || 'Term 1'}</span>
            </div>

            <button
              id="refresh-terminal-results-btn"
              onClick={loadTerminalResults}
              disabled={isLoading}
              className="min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] flex items-center justify-center p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition disabled:opacity-50 focus:outline-hidden focus:ring-2 focus:ring-[#176B45] shrink-0 cursor-pointer border border-slate-200 dark:border-slate-700"
              title="Refresh Terminal Results"
              aria-label="Refresh Terminal Results"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#176B45]' : ''}`} />
            </button>
          </div>
        </div>

        {/* View Mode Switcher Tabs (Individual Learner vs Terminal Merit List) */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
          <button
            id="terminal-view-individual-btn"
            type="button"
            onClick={() => setViewMode('individual')}
            className={`py-2 px-3 rounded-lg text-xs sm:text-sm font-bold transition flex items-center justify-center space-x-2 cursor-pointer ${
              viewMode === 'individual'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs border border-slate-200/60 dark:border-slate-600'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Users className="w-4 h-4 text-[#176B45] dark:text-emerald-400" />
            <span>Individual Learner</span>
          </button>
          <button
            id="terminal-view-merit-btn"
            type="button"
            onClick={() => setViewMode('merit_list')}
            className={`py-2 px-3 rounded-lg text-xs sm:text-sm font-bold transition flex items-center justify-center space-x-2 cursor-pointer ${
              viewMode === 'merit_list'
                ? 'bg-[#176B45] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Terminal Merit List</span>
          </button>
        </div>

        {/* Filter Controls Grid */}
        <div className="p-3.5 sm:p-4 bg-slate-50/70 dark:bg-slate-800/40 rounded-xl border border-slate-200/60 dark:border-slate-800">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 text-xs items-end">
            {viewMode === 'individual' ? (
              <>
                {/* Class Selector */}
                <div className="w-full">
                  <label htmlFor="terminal-class-select" className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5 text-xs sm:text-sm">
                    Class & Stream
                  </label>
                  <select
                    id="terminal-class-select"
                    value={selectedClassId}
                    onChange={(e) => {
                      setSelectedClassId(e.target.value);
                      setSelectedStudentId('');
                    }}
                    className="h-10 w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 text-slate-800 dark:text-slate-200 font-medium text-xs sm:text-sm focus:ring-2 focus:ring-[#176B45] focus:outline-hidden cursor-pointer shadow-2xs"
                  >
                    <option value="">Select Class & Stream...</option>
                    {accessibleClasses.map((cls) => (
                      <option
                        key={cls.stream_id || (cls.stream ? `${cls.id}_${cls.stream}` : cls.id)}
                        value={cls.stream_id || cls.id}
                      >
                        {cls.class_name} {cls.stream ? `(${cls.stream})` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Learner Selector */}
                <div className="w-full">
                  <label htmlFor="terminal-learner-select" className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5 text-xs sm:text-sm">
                    Learner
                  </label>
                  <select
                    id="terminal-learner-select"
                    value={selectedStudentId}
                    onChange={(e) => {
                      const newId = e.target.value;
                      if (newId !== selectedStudentId) {
                        if (newId) {
                          setIsLoading(true);
                        }
                        setSelectedStudentId(newId);
                      }
                    }}
                    disabled={!selectedClassId || classStudents.length === 0}
                    className="h-10 w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 text-slate-800 dark:text-slate-200 font-medium text-xs sm:text-sm focus:ring-2 focus:ring-[#176B45] focus:outline-hidden disabled:opacity-50 cursor-pointer shadow-2xs"
                  >
                    {!selectedClassId ? (
                      <option value="">Select Class & Stream First...</option>
                    ) : classStudents.length === 0 ? (
                      <option value="">No learners found in class</option>
                    ) : (
                      <>
                        <option value="">Select Learner...</option>
                        {classStudents.map((stu) => (
                          <option key={stu.id} value={stu.id}>
                            {getStudentFullName(stu)} {stu.admission_number ? `(${stu.admission_number})` : ''}
                          </option>
                        ))}
                      </>
                    )}
                  </select>
                </div>
              </>
            ) : (
              <>
                {/* Merit Grade Selector */}
                <div className="w-full">
                  <label htmlFor="terminal-merit-grade-select" className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5 text-xs sm:text-sm">
                    Class / Grade
                  </label>
                  <select
                    id="terminal-merit-grade-select"
                    value={meritGrade}
                    onChange={(e) => {
                      setMeritGrade(e.target.value);
                      setMeritStreamId('all');
                    }}
                    className="h-10 w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 text-slate-800 dark:text-slate-200 font-medium text-xs sm:text-sm focus:ring-2 focus:ring-[#176B45] focus:outline-hidden cursor-pointer shadow-2xs"
                  >
                    <option value="">Select Class / Grade...</option>
                    {accessibleGrades.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Merit Stream Selector */}
                <div className="w-full">
                  <label htmlFor="terminal-merit-stream-select" className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5 text-xs sm:text-sm">
                    Stream View
                  </label>
                  <select
                    id="terminal-merit-stream-select"
                    value={meritStreamId}
                    onChange={(e) => setMeritStreamId(e.target.value)}
                    disabled={!meritGrade}
                    className="h-10 w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 text-slate-800 dark:text-slate-200 font-medium text-xs sm:text-sm focus:ring-2 focus:ring-[#176B45] focus:outline-hidden disabled:opacity-50 cursor-pointer shadow-2xs"
                  >
                    <option value="all">All Streams (General Grade Cohort)</option>
                    {gradeStreams.map((st) => (
                      <option key={st.stream_id || st.id} value={st.stream_id || st.id}>
                        Stream: {st.stream || st.class_name}
                      </option>
                    ))}
                  </select>
                </div>
              </>
            )}

            {/* Result Mode (Official vs Provisional) - Staff Gated */}
            <div className="w-full">
              <label className="block text-slate-700 dark:text-slate-300 font-bold mb-1.5 text-xs sm:text-sm">
                Result Mode
              </label>
              {isStaff ? (
                <div className="h-10 w-full flex items-center rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-1 shadow-2xs">
                  <button
                    id="terminal-mode-official-btn"
                    onClick={() => setIsProvisionalMode(false)}
                    className={`h-full flex-1 rounded-md text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                      !isProvisionalMode
                        ? 'bg-[#176B45] text-white shadow-2xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    <span>Official</span>
                  </button>

                  <button
                    id="terminal-mode-provisional-btn"
                    onClick={() => setIsProvisionalMode(true)}
                    className={`h-full flex-1 rounded-md text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                      isProvisionalMode
                        ? 'bg-amber-600 text-white shadow-2xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>Provisional</span>
                  </button>
                </div>
              ) : (
                <div className="h-10 w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center space-x-1.5 shadow-2xs">
                  <ShieldCheck className="w-4 h-4 text-[#176B45] shrink-0" />
                  <span>Official Mode</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Provisional Mode Warning Banner */}
        {isProvisionalMode && isStaff && (
          <div
            id="provisional-mode-banner"
            className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-lg flex items-start space-x-2 text-xs text-amber-900 dark:text-amber-200"
          >
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold">Provisional Terminal Results Active</span>
              <p className="text-xs text-amber-800 dark:text-amber-300/90">
                Displaying results using Approved and Provisional contributing assessments. Staff review only. Not for official learner release.
              </p>
            </div>
          </div>
        )}

        {/* Incompatible Mixed Assessment Structures Warning Banner */}
        {contributingStructureInfo.isMixed && (
          <div
            id="terminal-mixed-structure-banner"
            className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 rounded-lg flex items-start space-x-2 text-xs text-rose-900 dark:text-rose-200"
          >
            <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold">Incompatible Assessment Structures</span>
              <p className="text-xs text-rose-800 dark:text-rose-300/90">
                {contributingStructureInfo.reason || 'Cannot combine Composite and Standalone assessments into one terminal result.'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 2. View Body: Terminal Merit List or Individual Learner View */}
      {viewMode === 'merit_list' ? (
        (isLoading || isMeritLoading) ? (
          <div
            id="terminal-merit-loading-state"
            className="bg-white dark:bg-slate-900 rounded-xl p-12 border border-slate-200 dark:border-slate-800 text-center shadow-xs space-y-3"
          >
            <Loader2 className="w-8 h-8 text-[#176B45] animate-spin mx-auto" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              Loading Terminal Merit List from Database…
            </h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Detecting keyed-in exams, subject allocations, and learner marks from Supabase for {meritGrade || 'selected class'}.
            </p>
          </div>
        ) : meritListData ? (
          <CbeTerminalMeritListReport
            data={meritListData}
            onRefresh={loadTerminalResults}
          />
        ) : (
          <div
            id="terminal-merit-empty-state"
            className="bg-white dark:bg-slate-900 rounded-xl p-12 border border-slate-200 dark:border-slate-800 text-center shadow-xs space-y-3"
          >
            <Award className="w-10 h-10 text-slate-400 mx-auto" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              No Merit List Records Available
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Please ensure a class/grade is selected and contributing assessments have marks recorded for this academic session.
            </p>
          </div>
        )
      ) : (
        <>
          {/* Learner Context Summary Card */}
          {selectedStudent && (
            <div
              id="terminal-learner-card"
              className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 sm:space-y-5"
            >
              {/* Tier 1: Learner Identity & Session Context Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 pb-4 border-b border-slate-100 dark:border-slate-800/80">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div
                    aria-hidden="true"
                    className="w-11 h-11 shrink-0 rounded-xl bg-gradient-to-br from-[#176B45] to-emerald-700 text-white font-black text-sm flex items-center justify-center shadow-xs ring-2 ring-emerald-500/20 select-none"
                  >
                    {getStudentInitials(selectedStudent)}
                  </div>

                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base sm:text-lg lg:text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                        {getStudentFullName(selectedStudent)}
                      </h3>
                      {selectedStudent.admission_number && (
                        <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2.5 py-0.5 rounded-md border border-slate-200 dark:border-slate-700">
                          {selectedStudent.admission_number}
                        </span>
                      )}
                      <span
                        className={`text-xs font-bold px-2.5 py-0.5 rounded-full border inline-flex items-center gap-1.5 ${
                          isProvisionalMode
                            ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-200 dark:border-amber-800'
                            : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 border-emerald-200 dark:border-emerald-800'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            isProvisionalMode ? 'bg-amber-500' : 'bg-emerald-500'
                          }`}
                        />
                        {isProvisionalMode ? 'Provisional Result' : 'Official Result'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
                      <span>
                        Class:{' '}
                        <strong className="text-slate-700 dark:text-slate-200 font-semibold">
                          {selectedClassStream?.class_name}{' '}
                          {selectedClassStream?.stream ? `(${selectedClassStream.stream})` : ''}
                        </strong>
                      </span>
                      <span className="text-slate-300 dark:text-slate-600">·</span>
                      <span>
                        Level:{' '}
                        <strong className="text-slate-700 dark:text-slate-200 font-semibold">
                          {selectedClassStream?.education_level || 'Junior School'}
                        </strong>
                      </span>
                      <span className="text-slate-300 dark:text-slate-600">·</span>
                      <span>
                        Session:{' '}
                        <strong className="text-slate-700 dark:text-slate-200 font-semibold">
                          {viewingYear?.year || '2026'} · {viewingTerm?.term_name || 'Term 1'}
                        </strong>
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tier 2: Balanced Responsive Metrics Grid */}
              <div
                className={`grid gap-2.5 sm:gap-3 ${
                  summaryMetrics.incompleteCount > 0
                    ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6'
                    : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'
                }`}
              >
                {/* 1. Assessments */}
                <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                  <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Assessments
                  </span>
                  <div className="mt-1 flex items-baseline">
                    <span className="text-sm sm:text-base lg:text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                      {summaryMetrics.assessmentCount}
                    </span>
                  </div>
                </div>

                {/* 2. Complete */}
                <div className="bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200/90 dark:border-emerald-800/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-emerald-300 transition-colors">
                  <span className="block text-[10px] font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                    Complete
                  </span>
                  <div className="mt-1 flex items-baseline">
                    <span className="text-sm sm:text-base lg:text-lg font-black text-emerald-800 dark:text-emerald-300 tracking-tight">
                      {summaryMetrics.completeCount}
                    </span>
                  </div>
                </div>

                {/* 2b. Incomplete (conditional) */}
                {summaryMetrics.incompleteCount > 0 && (
                  <div className="bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/90 dark:border-amber-800/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-amber-300 transition-colors">
                    <span className="block text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                      Incomplete
                    </span>
                    <div className="mt-1 flex items-baseline">
                      <span className="text-sm sm:text-base lg:text-lg font-black text-amber-800 dark:text-amber-300 tracking-tight">
                        {summaryMetrics.incompleteCount}
                      </span>
                    </div>
                  </div>
                )}

                {/* Upper Primary Metrics */}
                {isUpperPrimary && (
                  <>
                    <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                      <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Terminal Total
                      </span>
                      <div className="mt-1 flex items-baseline gap-1">
                        <span className="text-sm sm:text-base lg:text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                          {summaryMetrics.upTotalMarks !== null ? summaryMetrics.upTotalMarks : '—'}
                        </span>
                        {summaryMetrics.upTotalMarks !== null && (
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            / {summaryMetrics.upTotalMax}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                      <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Mean Score
                      </span>
                      <div className="mt-1 flex items-baseline">
                        <span className="text-sm sm:text-base lg:text-lg font-black text-[#176B45] dark:text-emerald-400 tracking-tight">
                          {summaryMetrics.upMeanScore !== null ? `${summaryMetrics.upMeanScore}%` : '—'}
                        </span>
                      </div>
                    </div>

                    <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                      <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Total Points
                      </span>
                      <div className="mt-1 flex items-baseline gap-1">
                        <span className="text-sm sm:text-base lg:text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                          {summaryMetrics.upTotalPoints !== null ? summaryMetrics.upTotalPoints : '—'}
                        </span>
                        {summaryMetrics.upTotalPoints !== null && (
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            / {summaryMetrics.upPointsMax}
                          </span>
                        )}
                      </div>
                    </div>
                  </>
                )}

                {/* Junior School Metrics */}
                {isJuniorSchool && (
                  <>
                    <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                      <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        Terminal Total
                      </span>
                      <div className="mt-1 flex items-baseline gap-1">
                        <span className="text-sm sm:text-base lg:text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                          {selectedLearnerRanking?.isRankable && selectedLearnerRanking.terminalTotalMarks !== null
                            ? selectedLearnerRanking.terminalTotalMarks
                            : '—'}
                        </span>
                        {selectedLearnerRanking?.isRankable && selectedLearnerRanking.terminalTotalMarks !== null && (
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            / {selectedLearnerRanking.terminalTotalMaximum}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                      <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider truncate">
                        {isProvisionalMode ? 'Prov. Stream Pos' : 'Stream Pos'}
                      </span>
                      <div className="mt-1 flex items-baseline gap-1">
                        <span className="text-sm sm:text-base lg:text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                          {selectedLearnerRanking?.isRankable && selectedLearnerRanking.streamPosition !== null
                            ? selectedLearnerRanking.streamPosition
                            : '—'}
                        </span>
                        {selectedLearnerRanking?.isRankable && selectedLearnerRanking.streamPosition !== null && (
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            / {selectedLearnerRanking.streamPositionDenominator}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/60 rounded-xl p-3 flex flex-col justify-between min-h-[68px] hover:border-slate-300 dark:hover:border-slate-600 transition-colors">
                      <span className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider truncate">
                        {isProvisionalMode ? 'Prov. Overall Pos' : 'Overall Pos'}
                      </span>
                      <div className="mt-1 flex items-baseline gap-1">
                        <span className="text-sm sm:text-base lg:text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                          {selectedLearnerRanking?.overallPosition !== null
                            ? selectedLearnerRanking.overallPosition
                            : '—'}
                        </span>
                        {selectedLearnerRanking?.overallPosition !== null && (
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            / {selectedLearnerRanking.overallPositionDenominator}
                          </span>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Tier 3: Elevated Action Toolbar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3.5 border-t border-slate-100 dark:border-slate-800">
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    id="preview-terminal-report-btn"
                    onClick={() => setIsReportModalOpen(true)}
                    disabled={contributingAssessments.length === 0}
                    className="min-h-[40px] inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 hover:border-slate-400 active:scale-[0.99] disabled:opacity-50 transition shadow-2xs cursor-pointer"
                  >
                    <Eye className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                    <span>Preview Report Form</span>
                  </button>

                  <button
                    id="download-terminal-report-btn"
                    onClick={handleDownloadSinglePDF}
                    disabled={isDownloadingSingle || contributingAssessments.length === 0}
                    className="min-h-[40px] inline-flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#176B45] hover:bg-[#125335] active:scale-[0.99] disabled:opacity-50 transition shadow-xs cursor-pointer"
                  >
                    {isDownloadingSingle ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    <span>Download PDF</span>
                  </button>

                  {classStudents.length > 1 && (
                    <button
                      id="batch-download-terminal-reports-btn"
                      onClick={handleBatchDownloadPDF}
                      disabled={isBatchDownloading || contributingAssessments.length === 0}
                      className="min-h-[40px] inline-flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold text-[#176B45] dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 active:scale-[0.99] disabled:opacity-50 transition shadow-2xs cursor-pointer"
                    >
                      {isBatchDownloading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <FileDown className="w-4 h-4" />
                      )}
                      <span>
                        {isBatchDownloading && batchProgress
                          ? `Batch PDF (${batchProgress.current}/${batchProgress.total})`
                          : `Batch PDF (${classStudents.length} Learners)`}
                      </span>
                    </button>
                  )}
                </div>

                {isUpperPrimary && (
                  <label className="min-h-[40px] inline-flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300 select-none cursor-pointer border border-slate-200 dark:border-slate-700 px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 shadow-2xs hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                    <input
                      type="checkbox"
                      id="hide-subcomponents-checkbox"
                      checked={hideSubComponents}
                      onChange={(e) => setHideSubComponents(e.target.checked)}
                      className="rounded border-slate-300 dark:border-slate-700 text-[#176B45] focus:ring-[#176B45] h-4 w-4 cursor-pointer"
                    />
                    <span>Hide Sub-components</span>
                  </label>
                )}
              </div>

              {batchDownloadError && (
                <div
                  id="terminal-batch-error-banner"
                  className="mt-3 flex items-center justify-between p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-medium"
                >
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{batchDownloadError}</span>
                  </div>
                  <button
                    onClick={() => setBatchDownloadError(null)}
                    className="text-xs text-rose-600 dark:text-rose-400 hover:underline ml-3 shrink-0 cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              )}
            </div>
          )}

      {/* 3. Main Results Presentation Area */}
      {isLoading ? (
        <div
          id="terminal-loading-state"
          className="bg-white dark:bg-slate-900 rounded-xl p-12 border border-slate-200 dark:border-slate-800 text-center shadow-xs space-y-3"
        >
          <Loader2 className="w-8 h-8 text-[#176B45] animate-spin mx-auto" />
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            Discovering Contributing Assessments…
          </h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Querying authoritative assessments, stream approvals, learner marks, and resolution provenance.
          </p>
        </div>
      ) : discoveryError ? (
        <div
          id="terminal-error-state"
          className="bg-rose-50 dark:bg-rose-950/40 rounded-xl p-8 border border-rose-200 dark:border-rose-800 text-center shadow-xs space-y-3"
        >
          <AlertTriangle className="w-8 h-8 text-rose-600 dark:text-rose-400 mx-auto" />
          <h4 className="text-sm font-bold text-rose-900 dark:text-rose-200">
            Unable to Load Terminal Results
          </h4>
          <p className="text-xs text-rose-700 dark:text-rose-300 max-w-md mx-auto font-mono">
            {discoveryError}
          </p>
          <button
            onClick={loadTerminalResults}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition inline-flex items-center space-x-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry Query</span>
          </button>
        </div>
      ) : !selectedStudent ? (
        <div
          id="terminal-no-student-state"
          className="bg-white dark:bg-slate-900 rounded-xl p-12 border border-slate-200 dark:border-slate-800 text-center shadow-xs space-y-2"
        >
          <Users className="w-8 h-8 text-slate-400 mx-auto" />
          <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300">
            No Learner Selected
          </h4>
          <p className="text-xs text-slate-500">
            Select a class and learner above to view Terminal Results.
          </p>
        </div>
      ) : contributingAssessments.length === 0 ? (
        <div
          id="terminal-empty-assessments-state"
          className="bg-white dark:bg-slate-900 rounded-xl p-12 border border-dashed border-slate-200 dark:border-slate-800 text-center shadow-xs space-y-3"
        >
          <FileText className="w-8 h-8 text-slate-400 mx-auto" />
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            No Contributing Assessments Discovered
          </h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            No {isProvisionalMode ? 'provisional or approved' : 'approved'} examinations were found for{' '}
            <strong>{selectedClassStream?.class_name}</strong> in {viewingYear?.year} {viewingTerm?.term_name}.
          </p>
          {isStaff && !isProvisionalMode && (
            <button
              onClick={() => setIsProvisionalMode(true)}
              className="px-3 py-1.5 bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-800 rounded-lg text-xs font-bold transition hover:bg-amber-100"
            >
              Check Provisional Mode
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {/* Desktop Table View */}
          <div className="hidden md:block">
            <TerminalResultsTable
              subjects={applicableSubjects}
              contributingAssessments={contributingAssessments}
              resultsBySubject={resultsBySubject}
              onSelectSubjectForTrail={handleOpenTrail}
            />
          </div>

          {/* Mobile Adaptive Cards View */}
          <div className="block md:hidden space-y-3">
            {applicableSubjects.map((subject) => {
              const res = resultsBySubject.get(subject.id);
              return (
                <TerminalResultsCard
                  key={subject.id}
                  subject={subject}
                  contributingAssessments={contributingAssessments}
                  result={res}
                  onSelectTrail={() => {
                    if (res) handleOpenTrail(subject, res);
                  }}
                />
              );
            })}
          </div>
        </div>
      )}
        </>
      )}

      {/* 4. Assessment Trail Slide-Over Drawer */}
      <AssessmentTrailDrawer
        isOpen={isTrailOpen}
        onClose={handleCloseTrail}
        subject={trailSubject}
        result={trailResult}
      />

      {/* 5. Terminal Report Form & PDF Presentation Modal */}
      {selectedStudent && (
        <TerminalReportModal
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
          student={selectedStudent}
          school={school}
          classStream={selectedClassStream || undefined}
          academicYear={viewingYear?.year || 2026}
          term={viewingTerm?.term_name || 'Term 1'}
          isProvisionalMode={isProvisionalMode}
          contributingAssessments={contributingAssessments}
          subjects={applicableSubjects}
          resultsBySubject={resultsBySubject}
          grades={grades}
          teachers={teachers}
          classes={classes}
          nextTermOpeningDate={(viewingTerm as any)?.next_term_opening_date || (viewingTerm as any)?.nextTermOpeningDate}
          ranking={selectedLearnerRanking || undefined}
          assessmentRankings={selectedLearnerAssessmentRankings}
          subjectRanks={learnerSubjectRanks}
          hideSubComponents={hideSubComponents}
          onToggleHideSubComponents={setHideSubComponents}
          streamSubjectAverages={selectedLearnerStreamSubjectAverages}
        />
      )}

      {/* 6. MANDATORY NEXT TERM OPENING DATE GATE MODAL */}
      <NextTermOpeningDateModal
        isOpen={Boolean(dateModalConfig?.isOpen)}
        exam={contributingAssessments[0] as any}
        reportType="terminal"
        reportTitle="Terminal Report"
        termName={viewingTerm?.term_name}
        year={viewingYear?.year}
        schoolTerms={api.getSchoolTerms()}
        initialDate={(viewingTerm as any)?.next_term_opening_date || (viewingTerm as any)?.nextTermOpeningDate}
        studentName={dateModalConfig?.student?.full_name}
        totalCount={dateModalConfig?.context === 'batch' ? classStudents.length : undefined}
        cohortCount={dateModalConfig?.context === 'batch' ? classStudents.length : undefined}
        downloadContext={dateModalConfig?.context || 'single'}
        onConfirm={(confirmedDate) => {
          if (dateModalConfig?.context === 'single') {
            setDateModalConfig(null);
            executeSinglePDFDownload(confirmedDate);
          } else {
            executeBatchPDFDownload(confirmedDate).finally(() => {
              setDateModalConfig(null);
            });
          }
        }}
        onClose={() => setDateModalConfig(null)}
        isProcessing={isDownloadingSingle || isBatchDownloading}
        batchProgress={batchProgress}
      />
    </div>
  );
};
